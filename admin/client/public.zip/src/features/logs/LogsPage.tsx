import { useEffect } from 'react'
import { useAppDispatch, useAppSelector } from '../../app/hooks'
import { AccessLogsTable } from './components/AccessLogsTable'
import { SystemLogsPanel } from './components/SystemLogsPanel'
import { loadLogs } from './logsSlice'
import { Loader } from '../../components/ui/Loader'
import { ErrorState } from '../../components/shared/ErrorState'

export const LogsPage = () => {
  const dispatch = useAppDispatch()
  const { access, system, status, error } = useAppSelector(
    (state) => state.logs,
  )

  useEffect(() => {
    if (status === 'idle') {
      dispatch(loadLogs())
    }
  }, [dispatch, status])

  return (
    <div className="content">
      <section className="page-title">
        <div>
          <h1>Security Logs</h1>
          <p>Audit trails across access and system events.</p>
        </div>
      </section>

      {status === 'loading' && <Loader />}
      {status === 'failed' && (
        <ErrorState message={error ?? 'Unable to load logs.'} />
      )}
      {status === 'succeeded' && (
        <section className="grid-2">
          <div className="panel table-panel">
            <div className="panel-header">
              <div>
                <p className="panel-title">Access Logs</p>
                <p className="panel-sub">Operator actions and downloads</p>
              </div>
            </div>
            <AccessLogsTable entries={access} />
          </div>
          <SystemLogsPanel entries={system} />
        </section>
      )}
    </div>
  )
}

export default LogsPage
