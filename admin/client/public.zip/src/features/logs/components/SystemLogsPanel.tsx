import type { LogEntry } from '../../../types/logs.types'

export const SystemLogsPanel = ({ entries }: { entries: LogEntry[] }) => {
  return (
    <div className="panel">
      <div className="panel-header">
        <div>
          <p className="panel-title">System Signals</p>
          <p className="panel-sub">Infrastructure anomalies</p>
        </div>
      </div>
      <div className="stack">
        {entries.map((entry) => (
          <div key={entry.id} className="stack-item">
            <div>
              <p className="panel-title">{entry.action}</p>
              <p className="panel-sub">{entry.actor}</p>
            </div>
            <span className="muted">{entry.time}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
