import { apiRequest } from '../../services/apiClient'
import { formatDate } from '../../utils/formatDate'
import type { LogEntry } from '../../types/logs.types'

export type LogsPayload = {
  access: LogEntry[]
  system: LogEntry[]
}

type AdminEvidenceResponse = {
  success: boolean
  data: {
    items: Array<{
      _id: string
      type: string
      timestamp: string
      blockchainStatus: string
      ownerAlias?: string
      ownerUserId?: {
        name?: string
      }
    }>
  }
}

export const fetchLogs = async (): Promise<LogsPayload> => {
  const response = await apiRequest<AdminEvidenceResponse>(
    '/api/admin/all-evidence?limit=100',
    {
      auth: true,
    },
  )

  const items = response.data.items

  const access: LogEntry[] = items.slice(0, 50).map((item) => ({
    id: `access-${item._id}`,
    actor: item.ownerUserId?.name || item.ownerAlias || 'Unknown',
    action: `${item.type} evidence activity`,
    status: item.blockchainStatus === 'ON_CHAIN' ? 'success' : 'warning',
    time: formatDate(item.timestamp),
  }))

  const system: LogEntry[] = items
    .filter((item) => item.blockchainStatus !== 'ON_CHAIN')
    .slice(0, 50)
    .map((item) => ({
      id: `system-${item._id}`,
      actor: 'Blockchain Pipeline',
      action: `${item.type} status: ${item.blockchainStatus}`,
      status:
        item.blockchainStatus === 'FAILED' || item.blockchainStatus === 'FAILED_RETRY'
          ? 'error'
          : 'warning',
      time: formatDate(item.timestamp),
    }))

  return { access, system }
}
