import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import type { LogEntry } from '../../types/logs.types'
import { fetchLogs, type LogsPayload } from './logsAPI'

type LogsState = {
  access: LogEntry[]
  system: LogEntry[]
  status: 'idle' | 'loading' | 'succeeded' | 'failed'
  error?: string
}

const initialState: LogsState = {
  access: [],
  system: [],
  status: 'idle',
}

export const loadLogs = createAsyncThunk<LogsPayload>('logs/load', async () => {
  return fetchLogs()
})

const logsSlice = createSlice({
  name: 'logs',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(loadLogs.pending, (state) => {
        state.status = 'loading'
        state.error = undefined
      })
      .addCase(loadLogs.fulfilled, (state, action) => {
        state.status = 'succeeded'
        state.access = action.payload.access
        state.system = action.payload.system
      })
      .addCase(loadLogs.rejected, (state) => {
        state.status = 'failed'
        state.error = 'Unable to load logs.'
      })
  },
})

export default logsSlice.reducer
