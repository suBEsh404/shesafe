import type { LogEntry } from '../../../types/logs.types'
import { getStatusColor } from '../../../utils/getStatusColor'

export const AccessLogsTable = ({ entries }: { entries: LogEntry[] }) => {
  return (
    <div className="table">
      <div className="table-row head">
        <span>Actor</span>
        <span>Action</span>
        <span>Status</span>
        <span>Time</span>
      </div>
      {entries.map((entry) => (
        <div key={entry.id} className="table-row">
          <span className="hash" data-label="Actor">{entry.actor}</span>
          <span data-label="Action">{entry.action}</span>
          <span className={getStatusColor(entry.status)} data-label="Status">
            <span className="status-dot" aria-hidden="true"></span>
            {entry.status}
          </span>
          <span className="muted" data-label="Time">{entry.time}</span>
        </div>
      ))}
    </div>
  )
}
